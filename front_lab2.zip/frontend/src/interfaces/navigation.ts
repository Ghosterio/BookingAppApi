export interface IDashboardNavItem {
    id: string
    title: string
    url: string
}

export interface IDashboardNavigation {
    id: string
    title: string
    links: IDashboardNavItem[]
}
