export interface IBooking{
    id: number
    chek_in_date: Date
    eviction_date: Date
    prepayment: boolean
    date_of_change: Date
    payment: IPayment
    status: IStatus
    user: IUser
    room: IRoom
    booking: IBookingB
}

export interface IPayment{
    id: number
    payment_Info: string
}

export interface IStatus{
    id: number
    status_Info: string
}

export interface IBookingB{
    id: number
    room_Name: string
    status_Info: string
}

export interface IRoom{
    id: number
    room_Name: string
}

export interface IUser{
    id: string
    userName: string
}

export interface IBookingQuery{
    id?: number;
    status?: number;
    search?: string;
    payment?: number;
    room?: number;
    Info?: string;
    orderBy?: string;
    offset?: number;
    pageSize?: number;
    sort?: string
}

export interface IBookingResponse {
    bookingDetails: IBooking[]
    totalItems: number,
    currentPage: number,
    totalPages: number
}