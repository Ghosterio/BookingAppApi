'use server'

import { IFormState } from '@/components/pages/participants/create-update'
import { revalidatePath } from 'next/cache'
import { doubleQuotedString } from '@/lib/utils'
import { IBookingQuery, IBookingResponse, IStatus } from "@/interfaces/booking";


export const getStatus = async (
): Promise<IStatus[] | { error: string }> => {

    const url = `${process.env.NEXT_PUBLIC_BACKEND_API_URL}status`
    const options = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.NEXT_PUBLIC_TOKEN}`
        }
    }

    console.log(url)

    try {
        const response = await fetch(encodeURI(url), options)

        if (response.ok) {
           
            return await response.json()
        }
        else {
            throw new Error()
        }
    }
    catch (error: unknown) {
        return { error: 'Ошибка номер статус' }
    }
}

