'use server'

import { IFormState } from '@/components/pages/participants/cr-up'
import { revalidatePath } from 'next/cache'
import { doubleQuotedString } from '@/lib/utils'
import { IBooking, IBookingQuery, IBookingResponse } from "@/interfaces/booking";
import { json } from 'stream/consumers';


export const getBooking_Details = async (
    params: IBookingQuery
): Promise<IBookingResponse | { error: string }> => {

    const url = `${process.env.NEXT_PUBLIC_BACKEND_API_URL}booking_details` +
        `?id=${params.id}` +
        `&OrderBy=${params.orderBy}` +
        `&StatusID=${params.status}` +
        `&PaymentID=${params.payment}` +
        `&RoomID=${params.room}` +
        `&search=${params.search}` +
        `&Room_Name=${params.Info}` +
        `&Offset=${params.offset}` +
        `&sort=${params.sort}` +
        `&PageSize=${params.pageSize}`
    const options = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.NEXT_PUBLIC_TOKEN}`
        }
    }

    console.log(url)

    try {
        const response = await fetch(encodeURI(url), options)
        if (response.ok) {
           
            return await response.json()
        }
        else {
            throw new Error()
        }
    }
    catch (error: unknown) {
        return { error: 'Ошибка' }
    }
}

export const getBooking_DetailsUD = async (
    id: number
): Promise<IBooking | { error: string }> => {

    const url = `${process.env.NEXT_PUBLIC_BACKEND_API_URL}booking_details/${id}`
    const options = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.NEXT_PUBLIC_TOKEN}`
        }
    }

    try {
        const response = await fetch(encodeURI(url), options)

        if (response.ok) {
            return await response.json()
        }
        else {
            throw new Error()
        }
    }
    catch (error: unknown) {
        return { error: 'Ошибка' }
    }
}

export const createBooking_Details = async (
    data: IFormState
): Promise<{ success: boolean } | { error: string }> => {
    const formData: IFormState = {
        id: data.id,
        eviction_date: data.eviction_date,
        chek_in_date: data.chek_in_date,
        date_of_change: data.date_of_change,
        prepayment: data.prepayment,
        userID: data.userID,
        paymentID: data.paymentID,
        bookingID: data.bookingID,      
    }

    const url = `${process.env.NEXT_PUBLIC_BACKEND_API_URL}booking_details/create`
    const options = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.NEXT_PUBLIC_TOKEN}`
        },
        body: JSON.stringify(formData)
    }
    console.log("Отправляемые данные:", JSON.stringify(formData))
    try {
        const response = await fetch(encodeURI(url), options)
        console.log("Статус ответа:", response.status); // Добавлено логирование статуса
        if (response.ok) {
            const responseData = await response.json();
            console.log("Данные ответа:", responseData); // Добавлено логирование тела ответа
            return responseData;
        }
        else {
            const errorData = await response.json();
            console.error("Ошибка от сервера:", errorData); //Логируем  ошибку с бэка
            throw new Error(JSON.stringify(errorData)); // Пробрасываем ошибку с деталями
        }
    }
    catch (error: any) { //Уточняем тип error
        console.error("Ошибка при выполнении запроса:", error);
        return { error: error.message || 'Ошибка' }; // Возвращаем сообщение об ошибке
    }
}

export const updateBooking_details = async (
    id: number,
    data: IFormState
): Promise<{ success: boolean } | { error: string }> => {
    console.log("updateBooking_details: Called with id=", id, "data=", data);
    const formData: IFormState = {
        id: data.id,
        eviction_date: data.eviction_date,
        chek_in_date: data.chek_in_date,
        date_of_change: data.date_of_change,
        prepayment: data.prepayment,
        userID: data.userID,
        paymentID: data.paymentID,
        bookingID: data.bookingID,
        
    }
    
    const url = `${process.env.NEXT_PUBLIC_BACKEND_API_URL}booking_details/update/${id}`
    const options = {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.NEXT_PUBLIC_TOKEN}`
            
        },
        body: JSON.stringify(formData)
    }

    try {
        const response = await fetch(encodeURI(url), options)

        if (response.ok) {
            return await response.json()
        }
        else {
            throw new Error()
        }
    }
    catch (error: unknown) {
        return { error: 'Ошибка' }
    }
}

export const removeBooking_details = async (
    id: number
): Promise<{success: boolean} | { error: string }> => {
    
    const url = `${process.env.NEXT_PUBLIC_BACKEND_API_URL}booking_details/delete/${id}`
    const options = {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${process.env.NEXT_PUBLIC_TOKEN}`
        }
    }

    try {
        const response = await fetch(encodeURI(url), options)

        if (response.ok) {
            revalidatePath("/dashboard/participants")
            return await response.json()
        }
        else {
            throw new Error()
        }
    }
    catch (error: unknown) {
        return { error: 'Ошибка' }
    }
}
