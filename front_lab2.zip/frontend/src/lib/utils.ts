import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { IStatus } from '@/interfaces/notifications'
import { Badge } from '@/components/ui/badge'
import { STATUSES } from '@/constants/participants'

export function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs))
}

export const formatDate = (date: string) : string => {
    const newDate = new Date(date)

    return newDate.toLocaleDateString('ru-RU', {
        day: '2-digit',
        month: 'long',
        year: 'numeric'
    })
}

export const formatStatus = (status: IStatus)=> {
    switch (status) {
        case STATUSES.NEW:
            return "Новая"
        case STATUSES.REPEATED:
            return "Повторная"
        case STATUSES.WRONG_DESIGN:
            return "Ошибки"
        case STATUSES.FAILED_ANTI_PLAGIARISM:
            return "Антиплагиат"
        case STATUSES.APPROVED:
            return "Принято"
        default:
            return status
    }
}

export const doubleQuotedString = (input : string) : string =>  {
    return `"${input}"`;
}