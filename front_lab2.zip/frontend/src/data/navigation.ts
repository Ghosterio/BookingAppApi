import {IDashboardNavigation} from "@/interfaces/navigation"

export const DASHBOARD_MENU: IDashboardNavigation[] = [
    {
        id: '1',
        title: 'Управление бронированиями',
        links: [
            {
                id: '1',
                title: 'Список бронирований',
                url: '/dashboard/participants'
            }
        ]
    }
]