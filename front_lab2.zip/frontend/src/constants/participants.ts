import * as zod from 'zod'

interface StatusType {
    [key: string]: 'new' | 'repeated' | 'wrong_design' | 'failed_anti_plagiarism' | 'approved'
}

export const STATUSES: StatusType = {
    NEW: 'new',
    REPEATED: 'repeated',
    WRONG_DESIGN: 'wrong_design',
    FAILED_ANTI_PLAGIARISM: 'failed_anti_plagiarism',
    APPROVED: 'approved'
}

const stringToDate = zod.preprocess((arg) => {
    if (typeof arg == "string" || arg instanceof Date) return new Date(arg);
  }, zod.date())

export const CREATE_NOTIFICATION_SCHEMA = zod.object({
    bookingID: zod.number().min(1, "Обязательное поле"),
    userID: zod.string().min(1, "Обязательное поле"),
    paymentID: zod.number().min(1, "Обязательное поле"),
    chek_in_date: stringToDate,
    eviction_date: stringToDate,
    prepayment: zod.boolean(),
    date_of_change: stringToDate,
})
