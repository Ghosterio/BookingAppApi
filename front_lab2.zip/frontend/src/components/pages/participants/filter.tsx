import { FC } from 'react'
import SearchInput from '@/components/ui/search-input'
import LimitFilter from '@/components/pages/participants/limit-filter'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import StatusFilter from './filterstatus'
import PaymentFilter from './filterpayment'
import RoomFilter from './filterroom'
import { Plus } from 'lucide-react'
import { getStatus } from '@/lib/api/status'
import { IPayment, IRoom, IStatus } from '@/interfaces/booking'
interface Filterprops{
    statusFilter: IStatus[];
    paymentFilter: IPayment[];
    roomFilter: IRoom[]
}

const Filter: FC <Filterprops> = ({statusFilter, paymentFilter, roomFilter}) => {
    return (
        <div
            className="flex items-end gap-4 mb-2"
        >
            <SearchInput />
            <LimitFilter />
            <StatusFilter 
            statusR={statusFilter}
            />
            <PaymentFilter
            paymentR={paymentFilter}
            />
            <RoomFilter
            roomR={roomFilter}
            />


            <Button
                className="ml-auto"
                variant="outline"
                asChild
            >
                <Link
                    href="/dashboard/participants/create"
                >
                    <Plus /> Добавить бронирование
                </Link>
            </Button>
        </div>
    )
}

export default Filter