'use client'

import { FC, useId } from 'react'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'


import { IPayment } from '@/interfaces/booking'
import { Badge } from '@/components/ui/badge'
import { number } from 'zod'


interface PaymentFilterProps {
    paymentR?: IPayment[]; 
  }
const PaymentFilter: FC<PaymentFilterProps> = ({ paymentR }) => {
    const paymentId = useId()
    const { replace } = useRouter()
    const pathname = usePathname()
    const searchParams = useSearchParams()
    const payment = searchParams.get('payment') || ''

    const handleChangePayment = (value: string) => {
        const params = new URLSearchParams(searchParams.toString())

        params.delete('offset')
        params.set('payment',value )

        replace(`${pathname}?${params.toString()}`)
    }

    return (
        
        <div
            className="flex flex-col gap-2"
        >
            <Label
                htmlFor={paymentId}
            >
                Оплата
            </Label>
            <Select
                defaultValue={payment}
                onValueChange={(value) => handleChangePayment(value)}
            >
                <SelectTrigger
                    className=""
                    id={paymentId}
                >
                    <SelectValue />
                </SelectTrigger>
                <SelectContent>
                    <SelectGroup>
                    
                    <SelectItem value="0">
          Все типы оплаты
        </SelectItem>
                        {paymentR?.map(item => (
                            <SelectItem 
                                key={item.id}
                                value={item.id.toString()}
                            >
                                {item.payment_Info}
                            </SelectItem>
                        ))}
                    </SelectGroup>
                </SelectContent>
            </Select>
        </div>
    )
}

export default PaymentFilter