'use client'

import { ChangeEvent, FC, FormEvent, useEffect, useState } from 'react'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'
import { useRouter } from 'next/navigation'
import { CREATE_NOTIFICATION_SCHEMA } from '@/constants/participants'
import { cn } from '@/lib/utils'
import { IBooking, IRoom, IUser, IStatus, IPayment, IBookingB } from '@/interfaces/booking'
import { updateBooking_details, createBooking_Details } from '@/lib/api/booking_datails'

interface CreateUpdateProps {
    chek_in_date: Date
    eviction_date: Date
    prepayment: Boolean
    date_of_change: Date
    user: IUser[]
    booking: IBookingB[]
    payment: IPayment[]
    booking_details?: IBooking
}

export interface IFormState {
    id: number
    userID: string
    bookingID: number
    paymentID: number
    chek_in_date: Date
    eviction_date: Date
    prepayment: boolean
    date_of_change: Date
}

interface IErrorState {
    bookingID: string[]
    userID: string[]
    statusID: string[]
    paymentID: string[]
    roomID: string[]
    chek_in_date: string[]
    eviction_date: string[]
    prepayment: string[]
    date_of_change: string[]
}

const INITIAL_FORM_STATE: IFormState = {
    id: 0,
    userID: '',
    bookingID: 0,
    paymentID: 0, 
    chek_in_date: new Date(),
    eviction_date: new Date(),
    prepayment: false,
    date_of_change: new Date()
}

const INITIAL_ERROR_STATE: IErrorState = {
    bookingID: [],
    userID: [],
    statusID: [],
    paymentID: [],
    roomID: [],
    chek_in_date: [],
    eviction_date: [],
    prepayment: [],
    date_of_change: [],
}

const CreateUpdate: FC<CreateUpdateProps> = (
    {
        booking,
        chek_in_date,
        eviction_date,
        prepayment,
        date_of_change,
        user,
        payment,
        booking_details

    }
) => {
    const router = useRouter()
    const [form, setForm] = useState<IFormState>(INITIAL_FORM_STATE)
    const [errors, setErrors] = useState<IErrorState>(INITIAL_ERROR_STATE)

    console.log("errors => ", errors)

    useEffect(() => {
        if (booking_details) {
            if (booking_details.user && booking_details.payment && booking_details.status) {
                const formState: IFormState = {
                    id: booking_details.id,
                    chek_in_date: booking_details.chek_in_date,
                    eviction_date: booking_details.eviction_date,
                    date_of_change: booking_details.date_of_change,
                    prepayment: booking_details.prepayment,
                    userID: booking_details.user.id,
                    paymentID: booking_details.payment.id,
                    bookingID: booking_details.status.id,
                };
                setForm(formState);
            } else {
                console.warn("Одно из свойств booking_datails (user, payment, status) равно null.");
            }
        }
    }, []);

    const handleChangeCheckbox = (e: ChangeEvent<HTMLInputElement>) => {
        const name = e.target.name
        const value = e.target.checked;

        if (errors[name as keyof IErrorState] && errors[name as keyof IErrorState].length) {
            setErrors(prev => ({ ...prev, [name]: [] }))
        }

        setForm(prev => ({ ...prev, [name]: value }))
    }

    const handleChangeDate = (e: ChangeEvent<HTMLInputElement>) => {
        const name = e.target.name;
        const value = e.target.value;
    
        if (errors[name as keyof IErrorState] && errors[name as keyof IErrorState].length) {
            setErrors(prev => ({ ...prev, [name]: [] }));
        }
    
        const [year, month, day] = value.split('-').map(Number);
    
        const utcDate = new Date(Date.UTC(year, month - 1, day));
    
        setForm(prev => ({ ...prev, [name]: utcDate }));
    };

    const handleChangeSelect = (value: number, name: string) => {
        setForm(prev => ({ ...prev, [name]: value }))
    }

    const handleChangeSelectSTR = (value: string, name: string) => {
        setForm(prev => ({ ...prev, [name]: value }))
    }

    const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault()
        
        const validation = CREATE_NOTIFICATION_SCHEMA.safeParse(form)

        if (!validation.success) {
            setErrors({ ...errors, ...validation.error.flatten().fieldErrors as IErrorState })           
        }
        
        const result = booking_details
            ? await updateBooking_details(form.id, form)
            : await createBooking_Details(form)
            console.log("Вызов updateBooking_details");
            console.log("result => ", result)

        console.log("Результат запроса:", result);
            
        console.log("result => ", result)

        if (!validation.success) {
            toast("Похоже, кто-то сожрал валидацию")
        }
        else {
            toast(
                'Успешно',
                {
                    className: 'border-green-500 bg-green-500',
                    description: "Бронирование успешно добавлено",
                    duration: 5000
                }
            )

            router.push('/dashboard/participants')
        }
    }

    const handleError = (errors: string[]) => {
        return errors.length ? errors.join(", ") : ''
    }






    return (
        <div
            className="flex flex-col gap-2 px-4 mt-8 mb-8"
        >
            <h1
                className="text-xl font-semibold mb-4"
            >
                {booking_details ? "Редактирование бронирования" : "Добавление бронирования"}
            </h1>

            <form
                className="flex flex-col gap-6"
                onSubmit={handleSubmit}
            >


                <div className="flex flex-col gap-2">
                    <Label htmlFor="booking">Бронирование</Label>
                    <Select
                        onValueChange={(value) => handleChangeSelect(Number(value), 'bookingID')}
                        defaultValue={booking_details?.booking?.id.toString()}
                    >
                        <SelectTrigger
                            className={cn({
                                'border-destructive': errors.bookingID.length > 0
                            })}
                            id="booking"
                        >
                            <SelectValue placeholder="Выберите бронирование" />
                        </SelectTrigger>
                        <SelectContent>
                            {booking.map((booking) => (
                                <SelectItem key={booking.id} value={booking.id.toString()}>
                                    {booking.room_Name} - {booking.status_Info}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    {errors.bookingID.length > 0 && (
                        <span className="text-red-500 text-sm">{handleError(errors.bookingID)}</span>
                    )}
                </div>

                <div
                    className="flex flex-col gap-2"
                >
                    <Label
                        htmlFor="user"
                    >
                        Пользователь
                    </Label>
                    <Select
                        onValueChange={(value) => handleChangeSelectSTR(value, 'userID')}
                        defaultValue={booking_details?.user?.id.toString()}
                    >

                        <SelectTrigger
                            className={cn({
                                'border-destructive': errors.userID.length > 0
                            })}
                            id="user"
                        >
                            <SelectValue placeholder="Укажите пользователя" />
                        </SelectTrigger>
                        <SelectContent>
                            {user.map((user) => (
                                <SelectItem
                                    key={user.id}
                                    value={user.id.toString()}
                                >
                                    {user.userName}
                                </SelectItem>
                            ))}
                        </SelectContent>
                        {errors.userID.length > 0 && (
                            <span className="text-red-500 text-sm">{handleError(errors.userID)}</span>
                        )}
                    </Select>
                </div>

                <div className="flex flex-col gap-2">
                    <Label htmlFor="payment">Оплата</Label>
                    <Select
                        onValueChange={(value) => handleChangeSelect(Number(value), 'paymentID')}
                        defaultValue={booking_details?.payment?.id.toString()}
                    >
                        <SelectTrigger
                            className={cn({
                                'border-destructive': errors.paymentID.length > 0
                            })}
                            id="payment"
                        >
                            <SelectValue placeholder="Выберите способ оплаты" />
                        </SelectTrigger>
                        <SelectContent>
                            {payment.map((payment) => (
                                <SelectItem key={payment.id} value={payment.id.toString()}>
                                    {payment.payment_Info}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    {errors.paymentID.length > 0 && (
                        <span className="text-red-500 text-sm">{handleError(errors.paymentID)}</span>
                    )}
                </div>

                <div className="flex flex-col gap-2">
                    <Label htmlFor="chek_in_date">Дата заезда</Label>
                    <Input
                        type="date"
                        id="chek_in_date"
                        name="chek_in_date"
                        value={typeof form.chek_in_date === 'string' ? form.chek_in_date : (form.chek_in_date as Date).toISOString().split('T')[0]}
                        onChange={handleChangeDate}
                        className={cn({ 'border-destructive': errors.chek_in_date.length > 0 })}
                    />
                    {errors.chek_in_date.length > 0 && (
                        <span className="text-red-500 text-sm">{handleError(errors.chek_in_date)}</span>
                    )}
                </div>

                <div className="flex flex-col gap-2">
                    <Label htmlFor="eviction_date">Дата выезда</Label>
                    <Input
                        type="date"
                        id="eviction_date"
                        name="eviction_date"
                        value={typeof form.eviction_date === 'string' ? form.eviction_date : (form.eviction_date as Date).toISOString().split('T')[0]}
                        onChange={handleChangeDate}
                        className={cn({ 'border-destructive': errors.eviction_date.length > 0 })}
                    />
                    {errors.eviction_date.length > 0 && (
                        <span className="text-red-500 text-sm">{handleError(errors.eviction_date)}</span>
                    )}
                </div>

                <div className="flex items-center space-x-2">
                    <Label htmlFor="prepayment">Предоплата</Label>
                    <Input
                        type="checkbox"
                        id="prepayment"
                        name="prepayment"
                        checked={form.prepayment}
                        onChange={handleChangeCheckbox}
                    />
                </div>

                <div className="flex flex-col gap-2">
                    <Label htmlFor="date_of_change">Дата изменения</Label>
                    <Input
                        type="date"
                        id="date_of_change"
                        name="date_of_change"
                        value={typeof form.date_of_change === 'string' ? form.date_of_change : (form.date_of_change as Date).toISOString().split('T')[0]}
                        onChange={handleChangeDate}
                        className={cn({ 'border-destructive': errors.date_of_change.length > 0 })}
                    />
                    {errors.date_of_change.length > 0 && (
                        <span className="text-red-500 text-sm">{handleError(errors.date_of_change)}</span>
                    )}
                </div>

                <Button
                    variant="default"
                    type="submit"
                >
                    Сохранить
                </Button>
            </form>
        </div>
    )
}

export default CreateUpdate