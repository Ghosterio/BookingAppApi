'use client'

import { FC, useId } from 'react'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'


import { IRoom } from '@/interfaces/booking'
import { Badge } from '@/components/ui/badge'
import { number } from 'zod'


interface RoomFilterProps {
    roomR?: IRoom[]; 
  }
const RoomFilter: FC<RoomFilterProps> = ({ roomR }) => {
    const roomId = useId()
    const { replace } = useRouter()
    const pathname = usePathname()
    const searchParams = useSearchParams()
    const room = searchParams.get('room') || ''

    const handleChangeRoom = (value: string) => {
        const params = new URLSearchParams(searchParams.toString())

        params.delete('offset')
        params.set('room',value )

        replace(`${pathname}?${params.toString()}`)
    }

    return (
        
        <div
            className="flex flex-col gap-2"
        >
            <Label
                htmlFor={roomId}
            >
                Комната
            </Label>
            <Select
                defaultValue={room}
                onValueChange={(value) => handleChangeRoom(value)}
            >
                <SelectTrigger
                    className=""
                    id={roomId}
                >
                    <SelectValue />
                </SelectTrigger>
                <SelectContent>
                    <SelectGroup>
                    
                    <SelectItem value="0">
          Все комнаты
        </SelectItem>
                        {roomR?.map(item => (
                            <SelectItem 
                                key={item.id}
                                value={item.id.toString()}
                            >
                                {item.room_Name}
                            </SelectItem>
                        ))}
                    </SelectGroup>
                </SelectContent>
            </Select>
        </div>
    )
}

export default RoomFilter