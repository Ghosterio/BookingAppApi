'use client'

import { FC, useId } from 'react'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'


import { IStatus } from '@/interfaces/booking'
import { Badge } from '@/components/ui/badge'
import { number } from 'zod'


interface StatusFilterProps {
    statusR?: IStatus[]; 
  }
const StatusFilter: FC<StatusFilterProps> = ({ statusR }) => {
    const statusId = useId()
    const { replace } = useRouter()
    const pathname = usePathname()
    const searchParams = useSearchParams()
    const status = searchParams.get('status') || ''

    const handleChangeStatus = (value: string) => {
        const params = new URLSearchParams(searchParams.toString())

        params.delete('offset')
        params.set('status',value )

        replace(`${pathname}?${params.toString()}`)
    }

    return (
        
        <div
            className="flex flex-col gap-2"
        >
            <Label
                htmlFor={statusId}
            >
                Статус
            </Label>
            <Select
                defaultValue={status}
                onValueChange={(value) => handleChangeStatus(value)}
            >
                <SelectTrigger
                    className=""
                    id={statusId}
                >
                    <SelectValue />
                </SelectTrigger>
                <SelectContent>
                    <SelectGroup>
                    
                    <SelectItem value="0">
          Все статусы
        </SelectItem>
                        {statusR?.map(item => (
                            <SelectItem 
                                key={item.id}
                                value={item.id.toString()}
                            >
                                {item.status_Info}
                            </SelectItem>
                        ))}
                    </SelectGroup>
                </SelectContent>
            </Select>
        </div>
    )
}

export default StatusFilter