'use client'

import { FC, useState } from 'react'
import {
    Table,
    TableBody,
    TableCaption,
    TableCell,
    TableFooter,
    TableHead,
    TableHeader,
    TableRow
} from "@/components/ui/table"
import {IBooking, IPayment, IRoom, IStatus} from "@/interfaces/booking";
import { formatDate } from '@/lib/utils'
import Filter from '@/components/pages/participants/filter'
import SortButton from '@/components/ui/sort-button'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { Pen, Trash2 } from 'lucide-react'
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { toast } from 'sonner'
import { removeBooking_details } from '@/lib/api/booking_datails';

interface ListProps {
    liststatus: IStatus[]
    listpayment: IPayment[]
    listroom: IRoom[]
    booking_details: IBooking[]
}

const List: FC<ListProps> = (
    {
        booking_details,
        liststatus,
        listpayment,
        listroom
    }
) => {
    const [openRemoveModal, setOpenRemoveModal] = useState(false)
    const [bookingIdToRemove, setBookingIdToRemove] = useState<number | null>(null)


    const handleRemoveBooking_details = async () => {
        if (bookingIdToRemove) {
            const result = await removeBooking_details(bookingIdToRemove)

            if (!result) {
                toast("Ошибка в удалении")
            }
            else {
                toast(
                    'Успешно',
                    {
                        className: 'border-green-500 bg-green-500',
                        description: "Бронирование успешно удалено",
                        duration: 5000
                    }
                )
            }
        }
    }

    return (
        <>
            <AlertDialog
                open={openRemoveModal}
                onOpenChange={setOpenRemoveModal}
            >
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>
                            Вы уверены что хотите удалить бронирование?
                        </AlertDialogTitle>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>
                            Отмена
                        </AlertDialogCancel>
                        <AlertDialogAction
                            onClick={handleRemoveBooking_details}
                        >
                            Удалить
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
            <div
                className="flex flex-col gap-2 px-4 mt-8"
            >
                <h1
                    className="text-xl font-semibold mb-4"
                >
                    Список бронирований
                </h1>

                <Filter 
                statusFilter={liststatus}
                paymentFilter={listpayment}
                roomFilter={listroom}
                />

                <Table>
                    <TableCaption>Бронирования</TableCaption>
                    <TableHeader>
                        <TableRow>
                            <TableHead>ID</TableHead>
                            <TableHead>
                                <SortButton
                                    sort="user"
                                >
                                    Пользователь
                                </SortButton>
                            </TableHead>
                            <TableHead>
                                <SortButton
                                    sort="chek_in_date"
                                >
                                    Дата заселения
                                </SortButton>
                            </TableHead>
                            <TableHead>
                                <SortButton
                                    sort="eviction_date"
                                >
                                    Дата выселения
                                </SortButton>
                            </TableHead>
                            <TableHead>
                                <SortButton
                                    sort="date_of_change"
                                >
                                    Дата изменения
                                </SortButton>
                            </TableHead>
                            <TableHead>
                                <SortButton
                                    sort="room_Name"
                                >
                                    Комната
                                </SortButton>
                            </TableHead>
                            <TableHead>
                                <SortButton
                                    sort="prepayment"
                                >
                                    Предоплата
                                </SortButton>
                            </TableHead>
                            <TableHead>
                                <SortButton
                                    sort="status"
                                >
                                    Статус
                                </SortButton>
                            </TableHead>
                            <TableHead>
                                <SortButton
                                    sort="payment"
                                >
                                    Оплата
                                </SortButton>
                            </TableHead>
                            <TableHead>Действия</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {booking_details?.map((booking_details, index) => (
                            <TableRow
                                key={booking_details.id}
                            >
                                <TableCell>{booking_details.id}</TableCell>
                                <TableCell>{booking_details.user.userName}</TableCell>
                                <TableCell
                                    className="w-[500px] whitespace-break-spaces"
                                >{booking_details.chek_in_date.toString()}</TableCell>
                                                                <TableCell
                                    className="w-[500px] whitespace-break-spaces"
                                >{booking_details.date_of_change.toString()}</TableCell>
                                                                <TableCell
                                    className="w-[500px] whitespace-break-spaces"
                                >{booking_details.eviction_date.toString()}</TableCell>
                                <TableCell>{booking_details.room.room_Name}</TableCell>
                                <TableCell>{booking_details.prepayment ? 'Да' : 'Нет'}</TableCell>
                                <TableCell>{booking_details.status.status_Info}</TableCell>
                                <TableCell>{booking_details.payment.payment_Info}</TableCell>
                                <TableCell>
                                    <div
                                        className="flex gap-2"
                                    >
                                        <Button
                                            variant="outline"
                                            size="icon"
                                            asChild
                                        >
                                            <Link
                                                href={`/dashboard/participants/${booking_details.id}`}
                                            >
                                                <Pen />
                                            </Link>
                                        </Button>
                                        <Button
                                            variant="destructive"
                                            size="icon"
                                            type="button"
                                            onClick={() => {
                                                setBookingIdToRemove(booking_details.id)
                                                setOpenRemoveModal(true)
                                            }}
                                        >
                                            <Trash2 />
                                        </Button>
                                    </div>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                    <TableFooter>
                        <TableRow>
                            <TableCell
                                className="text-right"
                            >
                                {booking_details?.length}
                            </TableCell>
                        </TableRow>
                    </TableFooter>
                </Table>
            </div>
        </>
    )
}

export default List