'use client'
import { useDebouncedCallback } from 'use-debounce'
import { FC, ChangeEvent, useState, useEffect, useId } from 'react'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import {
    Select,
    SelectContent,
    SelectGroup,
    SelectItem,
    SelectTrigger,
    SelectValue
} from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { handleClientScriptLoad } from 'next/script'

const LimitFilter: FC = ({}) => {
    const limitId = useId()
    const { replace } = useRouter()
    const pathname = usePathname()
    const searchParams = useSearchParams()
    const [currentLimit, setCurrentLimit] = useState(searchParams.get('pageSize') || 10)

    const handleLimit = useDebouncedCallback((value: string) => {
        const params = new URLSearchParams(searchParams.toString())

        params.delete('Offset')
        params.set('pageSize', value)

        if (!value) params.delete('pageSize')

        replace(`${pathname}?${params.toString()}`)
    }, 500)

    useEffect(() => {
        handleLimit(currentLimit as string)
    }, [currentLimit]);
    

    return (
        <div
            className="flex flex-col gap-2"
        >
            <Label
                htmlFor={limitId}
            >
                Кол-во записей
            </Label>
            <Select
                defaultValue='10'
                onValueChange={(value) => handleLimit(value)}
            >
                <SelectTrigger
                    className="w-[110px]"
                    id={limitId}
                >
                    <SelectValue />
                </SelectTrigger>
                <SelectContent>
                    <SelectGroup>
                        <SelectItem value="10">10</SelectItem>
                        <SelectItem value="20">20</SelectItem>
                        <SelectItem value="50">50</SelectItem>
                        <SelectItem value="100">100</SelectItem>
                    </SelectGroup>
                </SelectContent>
            </Select>
        </div>
    )
}
export default LimitFilter