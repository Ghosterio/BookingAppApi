'use client'

import { FC } from 'react'
import {
    Pagination,
    PaginationContent, PaginationEllipsis,
    PaginationItem,
    PaginationLink, PaginationNext,
    PaginationPrevious
} from '@/components/ui/pagination'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import { number } from 'zod'

interface DashboardPaginationProps {
    totalPages: number
    currentPage: number
}

const DashboardPagination: FC<DashboardPaginationProps> = (
    {
        totalPages,
        currentPage
    }
) => {
    const { replace } = useRouter()
    const pathname = usePathname()
    const searchParams = useSearchParams()

    const handleChangePage = (page: number) => {
        const params = new URLSearchParams(searchParams.toString())

        params.set('Offset', String(page))
        console.log(currentPage)
        

        replace(`${pathname}?${params.toString()}`)

    }

    return (
        <Pagination
            className="my-4"
        >
            <PaginationContent>
                <PaginationItem>
                    <Button
                        variant="outline"
                        type="button"
                        onClick={() => handleChangePage(currentPage - 1)}
                        disabled={currentPage === 1}
                    >
                        <ArrowLeft /> Назад
                    </Button>
                </PaginationItem>

                {Array.from({ length: totalPages }, (_, index) => (
                    <PaginationItem
                        key={index + 1}
                    >
                        <Button
                            variant={
                                currentPage === index + 1
                                    ? 'outline'
                                    : 'default'
                            }
                            type="button"
                            onClick={() => handleChangePage(index + 1)}
                        >
                            {index + 1}
                        </Button>
                    </PaginationItem>
                ))}

                <PaginationItem>
                    <Button
                        variant="outline"
                        type="button"
                        onClick={() => handleChangePage(currentPage + 1)}
                        disabled={currentPage === totalPages}
                    >
                        Следующая <ArrowRight />
                    </Button>
                </PaginationItem>
            </PaginationContent>
        </Pagination>

    )
}

export default DashboardPagination