'use client'

import { FC, ChangeEvent, useState, useEffect } from 'react'
import { Input } from '@/components/ui/input'
import { useSearchParams, usePathname, useRouter } from 'next/navigation'
import { useDebouncedCallback } from 'use-debounce'

const SearchInput: FC = ({}) => {
    const { replace } = useRouter()
    const pathname = usePathname()
    const searchParams = useSearchParams()
    const [currentSearch, setCurrentSearch] = useState(searchParams.get('search') || '')

    const handleSearch = useDebouncedCallback((value: string) => {
        const params = new URLSearchParams(searchParams.toString())

        params.delete('Offset')
        params.set('search', value)

        if (!value) params.delete('search')

        replace(`${pathname}?${params.toString()}`)
    }, 500)

    useEffect(() => {
        handleSearch(currentSearch)
    }, [currentSearch]);

    return (
        <Input
            className="w-[300px]"
            type="search"
            name="search"
            value={currentSearch}
            onChange={(e) => setCurrentSearch(e.target.value)}
            placeholder="Поиск"
        />
    )
}

export default SearchInput