'use client'

import { FC, ReactNode } from 'react'
import { Button } from '@/components/ui/button'
import { useRouter, usePathname, useSearchParams } from 'next/navigation'
import { ArrowUpAZ, ArrowDownZA } from 'lucide-react'

interface SortButtonProps {
    sort: string
    children: ReactNode
}

const SortButton: FC<SortButtonProps> = (
    {
        sort,
        children
    }
) => {
    const { replace } = useRouter()
    const pathname = usePathname()
    const searchParams = useSearchParams()
    const orderBy = searchParams.get('orderBy') || 'DESC'
    const currentSort = searchParams.get('sort') || 'createdAt'

    const handleSort = () => {
        const params = new URLSearchParams(searchParams.toString())

        params.delete('offset')
        params.set('orderBy', orderBy === 'ASC' ? 'DESC' : 'ASC')
        params.set('sort', sort)
        console.log("СОРТИРОВКА =>",`${pathname}?${params.toString()}`)

        replace(`${pathname}?${params.toString()}`)
    }

    return (
        <Button
            variant="ghost"
            type="button"
            onClick={handleSort}
        >
            {children}
            {
                currentSort === sort && (
                    orderBy === 'ASC'
                        ? (
                            <ArrowUpAZ />
                        )
                        : (
                            <ArrowDownZA />
                        )
                )
            }
        </Button>
    )
}

export default SortButton