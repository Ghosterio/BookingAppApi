'use client'

import { ComponentProps, FC } from 'react'
import {
    Sidebar,
    SidebarContent,
    SidebarGroup, SidebarGroupContent,
    SidebarGroupLabel,
    SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem,
    SidebarRail
} from "@/components/ui/sidebar"
import {DASHBOARD_MENU} from "@/data/navigation";
import {Collapsible, CollapsibleContent, CollapsibleTrigger} from "@/components/ui/collapsible";
import {ChevronRight} from "lucide-react";
import Link from "next/link";
import {usePathname} from "next/navigation";

interface DashboardSidebarProps extends ComponentProps<typeof Sidebar> {}

const DashboardSidebar: FC<DashboardSidebarProps> = (
    {
        ...props
    }
) => {
    const pathname = usePathname()

    return (
        <Sidebar
            {...props}
        >
            <SidebarHeader>
                Лого
            </SidebarHeader>
            <SidebarContent
                className="gap-0"
            >
                {DASHBOARD_MENU.map((category) => (
                    <Collapsible
                        key={category.id}
                        title={category.title}
                        defaultOpen
                        className="group/collapsible"
                    >
                        <SidebarGroup>
                            <SidebarGroupLabel
                                asChild
                                className="group/label text-sm text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                            >
                                <CollapsibleTrigger>
                                    {category.title}{" "}
                                    <ChevronRight
                                        className="ml-auto transition-transform group-data-[state=open]/collapsible:rotate-90"
                                    />
                                </CollapsibleTrigger>
                            </SidebarGroupLabel>
                            <CollapsibleContent>
                                <SidebarGroupContent>
                                    <SidebarMenu>
                                        {category.links.map((item) => (
                                            <SidebarMenuItem
                                                key={item.title}
                                            >
                                                <SidebarMenuButton
                                                    asChild
                                                    isActive={item.url === pathname}
                                                >
                                                    <Link
                                                        href={item.url}
                                                    >
                                                        {item.title}
                                                    </Link>
                                                </SidebarMenuButton>
                                            </SidebarMenuItem>
                                        ))}
                                    </SidebarMenu>
                                </SidebarGroupContent>
                            </CollapsibleContent>
                        </SidebarGroup>
                    </Collapsible>
                ))}
            </SidebarContent>
            <SidebarRail />
        </Sidebar>
    )
}

export default DashboardSidebar