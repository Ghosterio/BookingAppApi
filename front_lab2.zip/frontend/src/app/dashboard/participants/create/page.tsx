import { FC, Suspense } from 'react'
import CreateUpdate from '@/components/pages/participants/cr-up'
import { getRoom } from '@/lib/api/room'
import { getPayment } from '@/lib/api/payment'
import { getStatus } from '@/lib/api/status'
import { getBookingB } from '@/lib/api/booking'
import { getUser } from '@/lib/api/user'


const CreateBooking_DetailsPage: FC = async ({}) => {
    const user = await getUser()
    const payment = await getPayment()
    const booking = await getBookingB()

    if ('error' in payment) return <div>{payment.error}</div>
    if ('error' in user) return <div>{user.error}</div>
    if ('error' in booking) return <div>{booking.error}</div>

    const currentDate = new Date();

    return (
        <Suspense fallback={<div>Загрузка</div>}>
            <CreateUpdate
                booking={booking}
                chek_in_date={currentDate}
                prepayment={false}
                eviction_date={currentDate}
                date_of_change={currentDate}
                user={user}
                payment = {payment}
            />
        </Suspense>
    )
}

export default CreateBooking_DetailsPage