import React, {Suspense} from 'react'
import List from "@/components/pages/participants/list"
import { IBookingQuery} from '@/interfaces/booking'
import DashboardPagination from '@/components/ui/dashboard-pagination'
import { number } from 'zod'
import { getBooking_Details } from '@/lib/api/booking_datails'
import { getStatus } from '@/lib/api/status'
import { getPayment } from '@/lib/api/payment'
import { getRoom } from '@/lib/api/room'

type SearchParams = Promise<{ [key: string]: string | string[] | undefined }>

const ParticipantsPage = async (
    {
        searchParams
    }: {
        searchParams: SearchParams
    }
) => {
    const params = await searchParams
    const BookingParams: IBookingQuery = {
        id: Number(params.id) || 0,
        status: Number(params.status) || 0,
        search: params.search as string || '',
        payment: Number(params.payment) || 0,
        room: Number(params.room) || 0,
        Info: params.Info as string || '',
        sort: params.sort as string || '',
        orderBy: params.orderBy as 'ASC' | 'DESC'  ,
        offset: Number(params.Offset) || 1,
        pageSize: Number(params.pageSize) || 10
    }

    const data = await getBooking_Details(BookingParams)
    const liststatus = await getStatus()
    const listpayment = await getPayment()
    const listroom = await getRoom()
    console.log(params.pageSize)

    if ('error' in liststatus) return <div>{liststatus.error}</div>
    if ('error' in listpayment) return <div>{listpayment.error}</div>
    if ('error' in listroom) return <div>{listroom.error}</div>

    if ('error' in data) return <div>{data.error}</div>
    return (
        <Suspense
            fallback={<div>Загрузка</div>}
        >
            <List
                booking_details={data.bookingDetails}
                liststatus={liststatus}
                listpayment={listpayment}
                listroom={listroom}
            />
            <DashboardPagination
                totalPages={data.totalPages + 1}
                currentPage={data.currentPage}
            />
        </Suspense>
    )
}

export default ParticipantsPage