import { FC, Suspense } from 'react'
import CreateUpdate from '@/components/pages/participants/cr-up'
import { getBooking_DetailsUD } from '@/lib/api/booking_datails'
import { getRoom } from '@/lib/api/room'
import { getPayment } from '@/lib/api/payment'
import { getStatus } from '@/lib/api/status'
import { getUser } from '@/lib/api/user'
import getBaseWebpackConfig from 'next/dist/build/webpack-config'
import { getBookingB } from '@/lib/api/booking'



interface UpdateBooking_DetailsPageProps {
    params: Promise<{
        id: string
    }>
}

const UpdateBooking_DetailsPage: FC<UpdateBooking_DetailsPageProps> = async (
    {
        params
    }
) => {
    const { id } = await params

    const booking_details = await getBooking_DetailsUD(Number(id))
    const payment = await getPayment()
    const user = await getUser()
    const booking = await getBookingB()

    if ('error' in booking_details) return <div>{booking_details.error}</div>
    if ('error' in payment) return <div>{payment.error}</div>
    if ('error' in user) return <div>{user.error}</div>
    if ('error' in booking) return <div>{booking.error}</div>

    return (
        <Suspense fallback={<div>Загрузка</div>}>
            <CreateUpdate
                booking={booking}
                booking_details={booking_details}
                chek_in_date={booking_details.chek_in_date}
                prepayment={booking_details.prepayment}
                eviction_date={booking_details.eviction_date}
                date_of_change={booking_details.date_of_change}
                user={user}
                payment = {payment}
            />
        </Suspense>
    )
}

export default UpdateBooking_DetailsPage