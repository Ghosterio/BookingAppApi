import React from 'react'

const StatisticPage = () => {
    return (
        <>

        </>
    )
}

export default StatisticPage