import { ReactNode, FC } from 'react'
import {SidebarInset, SidebarProvider, SidebarTrigger} from "@/components/ui/sidebar";
import DashboardSidebar from "@/components/layout/dashboard-sidebar";
import {Separator} from "@/components/ui/separator";
import {
    Breadcrumb,
    BreadcrumbItem,
    BreadcrumbLink,
    BreadcrumbList, BreadcrumbPage,
    BreadcrumbSeparator
} from "@/components/ui/breadcrumb";
import Link from "next/link";

interface DashboardLayoutProps {
    children: ReactNode
}

const DashboardLayout: FC<DashboardLayoutProps> = (
    {
        children
    }
) => {
    return (
        <>
            <SidebarProvider>
                <DashboardSidebar />
                <SidebarInset>
                    <header
                        className="flex sticky top-0 bg-background h-16 shrink-0 items-center gap-2 border-b px-4"
                    >
                        <SidebarTrigger
                            className="-ml-1"
                        />
                        <Separator
                            orientation="vertical"
                            className="mr-2 h-4"
                        />
                        <Breadcrumb>
                            <BreadcrumbList>
                                <BreadcrumbItem
                                    className="hidden md:block"
                                >
                                    <BreadcrumbLink
                                        asChild
                                    >
                                        <Link
                                            href="/dashboard"
                                        >
                                            Статистика
                                        </Link>
                                    </BreadcrumbLink>
                                </BreadcrumbItem>
                                <BreadcrumbSeparator
                                    className="hidden md:block"
                                />
                                <BreadcrumbItem>
                                    <BreadcrumbPage>Извлечение данных</BreadcrumbPage>
                                </BreadcrumbItem>
                            </BreadcrumbList>
                        </Breadcrumb>
                    </header>
                    <div
                        className=""
                    >
                        {children}
                    </div>
                </SidebarInset>
            </SidebarProvider>
        </>
    )
}

export default DashboardLayout